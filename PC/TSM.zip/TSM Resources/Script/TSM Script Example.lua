--[[ 
TSM Lua Engine Example Script
This script demonstrates all available functions and features of the TSM Lua Engine.
You can use these functions to create custom scripts for That Sky Mod.
]]--

-- Utility Functions
function reloadLevel()
    local currentLevel = TSM.getLevelName()
    TSM.changeLevel(currentLevel)
    TSM.notify("Reloaded Level: " .. currentLevel)
end

function printCurrentPosition()
    local currentPosition = TSM.getPlayerPosition()
    TSM.notify(string.format("Position: X:%.2f Y:%.2f Z:%.2f", 
        currentPosition.x, currentPosition.y, currentPosition.z))
end

function teleportAvatar(x, y, z)
    TSM.teleport(x, y, z)
    TSM.notify(string.format("Teleported to: X:%.2f Y:%.2f Z:%.2f", x, y, z))
end

-- Avatar Control Functions
function speak(message)
    TSM.avatarSpeak(message)
    TSM.notify("Avatar said: " .. message)
end

function setAvatarPosition(x, y, z)
    TSM.avatarSetPos(x, y, z)
    TSM.notify(string.format("Set avatar position to: X:%.2f Y:%.2f Z:%.2f", x, y, z))
end

function crawlToggle(enabled)
    TSM.avatarCrawl(enabled)
    TSM.notify("Crawl mode: " .. (enabled and "Enabled" or "Disabled"))
end

function playEmote(emoteName, speed)
    speed = speed or 1.0
    TSM.avatarPlayEmote(emoteName, speed, 0, 1)
    TSM.notify("Playing emote: " .. emoteName)
end

-- Visual Effects Functions
function rainbowMode()
    TSM.avatarRainbowParty()
    TSM.notify("Rainbow mode enabled")
end

function setInnerGlow()
    TSM.avatarSetInnerGlow()
    TSM.notify("Inner glow applied")
end

function setTatteredCape(amount)
    TSM.setAvatarCapeTattered(amount)
    TSM.notify("Cape tattered amount set to: " .. amount)
end

function dyeOutfit(color, region, slot)
    TSM.avatarSetOutfitDye(color, region, slot)
    TSM.notify(string.format("Applied dye: %s to region %d, slot %s", color, region, slot))
end

function removeDye(color, region, slot)
    TSM.avatarRemoveOutfitDye(color, region, slot)
    TSM.notify(string.format("Removed dye from region %d, slot %s", region, slot))
end

-- Environment Control Functions
function setWeather(rainIntensity, windIntensity)
    TSM.setRainParams(rainIntensity)
    TSM.setWindIntensity(windIntensity)
    TSM.notify(string.format("Weather set - Rain: %.1f, Wind: %.1f", rainIntensity, windIntensity))
end

-- Special Effects Functions
function createShardnado(x, y, z)
    TSM.shardnado(x, y, z)
    TSM.notify("Created Shardnado effect")
end

function slowMotion(duration, speed)
    TSM.setBulletTime(duration, speed)
    TSM.notify(string.format("Bullet time: Duration %.1fs, Speed %.1f", duration, speed))
end

function setDesaturation(intensity, filterType)
    TSM.cameraDesaturationEffect(intensity, filterType)
    TSM.notify("Camera desaturation applied")
end

function placeMusicalMote(x, y, z)
    TSM.musicalMoteTarget(x, y, z)
    TSM.notify("Placed musical mote")
end

-- UI and Display Functions
function showTitle(main, sub)
    TSM.displayTitleCard(main, sub, true)
    TSM.notify("Displaying title card")
end

function showFloatingText(text, x, y)
    TSM.displayText(text, x, y)
    TSM.notify("Showing floating text")
end

function showHUD(textureName, isCreditLogo, x, y, z)
    TSM.showHUDInWorld(textureName, isCreditLogo, x, y, z)
    TSM.notify("Showing HUD element")
end

function showTimedHint(text)
    TSM.dialogHintTimed(text)
    TSM.notify("Showing timed hint")
end

function showQuestBanner()
    TSM.uiQuestBanner()
    TSM.notify("Showing quest banner")
end

function showTitleGate()
    TSM.titleGate()
    TSM.notify("Showing title gate")
end

function openOutfitSelect(x, y, z, showAllPurchased)
    TSM.outfitSelect(Vector3.new(x, y, z), showAllPurchased)
    TSM.notify("Opened outfit selection")
end

-- Social Functions
function triggerSocialActions()
    TSM.socialGift()
    TSM.socialFireworks()
    TSM.socialRandomGame()
    TSM.notify("Triggered social actions")
end

function setAudienceMode(showReactions, replaceLocal, replaceOthers)
    TSM.audienceSettings(showReactions, replaceLocal, replaceOthers)
    TSM.setLocalAudienceJelly()
    TSM.notify("Audience mode configured")
end

function doAudienceReaction(power, type)
    TSM.localDoAudienceReact(power, type)
    TSM.notify("Performed audience reaction")
end

-- Gameplay Functions
function grantPlayerSpell(spellName)
    TSM.grantSpell(spellName)
    TSM.notify("Granted spell: " .. spellName)
end

function removePlayerSpell(spellName)
    TSM.removeSpell(spellName)
    TSM.notify("Removed spell: " .. spellName)
end

function collectItem(item, type)
    TSM.collectCollectible(item, type)
    TSM.notify("Collected item: " .. item)
end

function useToy(toyName)
    TSM.triggerToyEvent(toyName)
    TSM.notify("Used toy: " .. toyName)
end

function addToStat(statName, value)
    TSM.addFloatToStatUsingName(statName, value)
    TSM.notify("Added to stat: " .. statName)
end

-- Music and Sound Functions
function playBackgroundMusic(trackName, volume)
    volume = volume or 1.0
    TSM.playMusic(trackName, true, volume)
    TSM.notify("Playing music: " .. trackName)
end

function playGameSound(soundName, volume)
    volume = volume or 1.0
    TSM.playSound2D(soundName, volume)
    TSM.notify("Playing sound: " .. soundName)
end

--[[ 
Example Usage:

-- Basic Functions
printCurrentPosition()                 -- Print current coordinates
teleportAvatar(100, 50, 200)           -- Teleport to specific coordinates
speak("Hello!")                   -- Make avatar speak
reloadLevel()                          -- Reload current level

-- Visual Effects
rainbowMode()                          -- Enable rainbow effect
setInnerGlow()                         -- Apply inner glow
setTatteredCape(0.5)                   -- Set cape tatter amount
dyeOutfit("Red", 1, "Body")            -- Dye outfit
setWeather(0.5, 0.3)                   -- Set rain and wind intensity

-- Special Effects
createShardnado(100, 50, 100)          -- Create shardnado effect
slowMotion(5.0, 0.5)                   -- Enable slow motion
setDesaturation(0.5, 1)                -- Apply camera effect
placeMusicalMote(100, 50, 100)         -- Place musical note

-- UI and Display
showTitle("Title", "Sub Title")        -- Show title card
showFloatingText("Hello!", 0.5, 0.5)   -- Show floating text
showTimedHint("Press Jump!")           -- Show timed hint
showQuestBanner()                      -- Show quest banner

-- Social and Gameplay
triggerSocialActions()                 -- Trigger social effects
setAudienceMode(true, false, false)    -- Configure audience mode
grantPlayerSpell("glow_15")            -- Grant light buff
useToy("message_gondola")              -- Use prop
addToStat("WingCount", 1)              -- Modify stat

-- Audio
playBackgroundMusic("theseed", 0.8)    -- Play background music
playGameSound("UIDailyQuestProgress", 1.0) -- Play sound effect
]]--

printCurrentPosition()