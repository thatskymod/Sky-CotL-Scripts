--[[ 
TSM API Example Script
This script demonstrates how to use the TSM API functions for memory manipulation
and pattern scanning.
]]--

-- Memory Manipulation Examples
function patchMemory()
    local bytes = TSM.API.hexToBytes("90909090") -- NOP instructions
    local address = 0x1234567
    local success = TSM.API.patch(address, bytes, true)
    TSM.notify(success and "Memory patched successfully" or "Failed to patch memory")
end

function writeValues()
    -- Write float value
    local floatAddress = 0x1234567
    TSM.API.writeFloat(floatAddress, 123.45)
    TSM.notify("Wrote float value")
    
    -- Write integer value
    local intAddress = 0x1234568
    TSM.API.writeInt(intAddress, 12345)
    TSM.notify("Wrote integer value")
    
    -- Patch string
    local stringAddress = 0x1234569
    TSM.API.patchString(stringAddress, "New String Value")
    TSM.notify("Patched string value")
end

function scanMemory()
    -- Basic pattern scan
    local result = TSM.API.scan("48 8B 05 ? ? ? ? 48 8B 48 08")
    TSM.notify(string.format("Pattern found at: 0x%X", result))
    
    -- Scan with specific range
    local rangeStart = 0x1000000
    local rangeSize = 0x1000
    local resultInRange = TSM.API.scan("48 8B 05", rangeStart, rangeSize)
    TSM.notify(string.format("Pattern in range found at: 0x%X", resultInRange))
end

--[[ 
Usage Examples:

-- Memory Patching
local nopBytes = TSM.API.hexToBytes("90909090")
TSM.API.patch(0x1234567, nopBytes, true)  -- Apply patch
TSM.API.patch(0x1234567, nopBytes, false) -- Restore original bytes

-- Value Writing
TSM.API.writeFloat(0x1234567, 100.5)    -- Write float
TSM.API.writeInt(0x1234567, 12345)      -- Write integer
TSM.API.patchString(0x1234567, "Hello") -- Write string

-- Pattern Scanning
local address = TSM.API.scan("48 8B 05 ? ? ? ?")
local rangeAddress = TSM.API.scan("48 8B 05", 0x1000000, 0x1000)
]]--